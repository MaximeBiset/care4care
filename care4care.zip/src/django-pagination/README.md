django-pagination-py3
=====================

A port of django-pagination to Python 3, also compatible with Python 2.x ;)


Installation
------------

Install it from pypi.python.org:

    pip install django-pagination-py3

or just clone this repository and run:

    python setup.py install


Usage
-----

Use it the same way you use django-pagination.
