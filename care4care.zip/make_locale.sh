#!/bin/bash
./manage.py makemessages --locale=en 
./manage.py makemessages --locale=nl 
