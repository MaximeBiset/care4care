(function() {
  $(function() {
    return console.log('Hello, Coffee!');
  });

}).call(this);
