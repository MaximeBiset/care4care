# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('main', '0027_auto_20141203_1712'),
        ('main', '0028_merge'),
    ]

    operations = [
    ]
