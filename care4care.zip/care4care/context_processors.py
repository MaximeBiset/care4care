from django.conf import settings

def member_type_global(request):
    return { 'NON_MEMBER_TYPE': 2 }
