#!/bin/bash
./manage.py compilemessages
