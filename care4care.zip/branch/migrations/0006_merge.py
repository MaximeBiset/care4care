# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('branch', '0005_auto_20141129_1015'),
        ('branch', '0005_auto_20141129_0939'),
    ]

    operations = [
    ]
