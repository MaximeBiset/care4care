# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('branch', '0040_merge'),
        ('branch', '0036_merge'),
    ]

    operations = [
    ]
