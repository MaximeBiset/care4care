# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('branch', '0046_auto_20141204_1818'),
        ('branch', '0045_auto_20141204_1532'),
    ]

    operations = [
    ]
