# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('branch', '0048_auto_20141204_2054'),
        ('branch', '0036_auto_20141204_1024'),
    ]

    operations = [
    ]
