# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('branch', '0050_merge'),
        ('branch', '0050_auto_20141205_1238'),
    ]

    operations = [
    ]
